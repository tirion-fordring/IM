package com.lld.im.codec.pack.friendship;

import lombok.Data;

/**
 * @author: Chackylee
 * @description: 删除黑名单通知报文
 **/
@Data
public class DeleteAllFriendPack {

    private String fromId;

}
