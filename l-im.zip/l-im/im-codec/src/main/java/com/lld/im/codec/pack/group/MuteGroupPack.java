package com.lld.im.codec.pack.group;

import lombok.Data;

/**
 * @author: Chackylee
 * @description: 禁言群tcp通知
 **/
@Data
public class MuteGroupPack {

    private String groupId;

}
