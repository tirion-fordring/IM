package com.lld.im.common.enums.command;

/**
 * @description:
 * @author: lld
 * @version: 1.0
 */
public interface Command {
    public int getCommand();
}
