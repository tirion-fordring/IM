package com.lld.message.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lld.message.dao.ImGroupMessageHistoryEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface ImGroupMessageHistoryMapper extends BaseMapper<ImGroupMessageHistoryEntity> {


}
