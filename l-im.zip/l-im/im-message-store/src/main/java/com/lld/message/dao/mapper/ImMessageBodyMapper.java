package com.lld.message.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lld.message.dao.ImMessageBodyEntity;
import org.springframework.stereotype.Repository;
@Repository
public interface ImMessageBodyMapper extends BaseMapper<ImMessageBodyEntity> {
}
