package com.lld.im.service.friendship.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lld.im.service.friendship.dao.ImFriendShipRequestEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ImFriendShipRequestMapper extends BaseMapper<ImFriendShipRequestEntity> {
}
