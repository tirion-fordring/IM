package com.lld.im.service.group.model.callback;

import lombok.Data;

/**
 * @description:
 * @author: lld
 * @version: 1.0
 */
@Data
public class DestroyGroupCallbackDto {

    private String groupId;
}
